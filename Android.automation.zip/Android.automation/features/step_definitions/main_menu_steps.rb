Given('I land on Home screen') do
  puts("I landed on Home screen")
end

When('I press on Menu icon') do
  puts("Menu icon pressed")
end

Then('I should see left side menu') do
  puts("I see left side menu")
end

When('I press on My conversions button') do
  puts("My conversions button pressed")
end

Then('I land on My conversions screen') do
  puts("Landed on My conversions screen")
end


